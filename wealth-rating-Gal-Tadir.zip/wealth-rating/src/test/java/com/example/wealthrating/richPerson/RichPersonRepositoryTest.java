package com.example.wealthrating.richPerson;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;


import java.util.Optional;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class RichPersonRepositoryTest {

    @Autowired
    private RichPersonRepository underTest;

    @AfterEach
    void tearDown() {
        underTest.deleteAll();
    }

    @Test
    void test1(){
        RichPerson richPerson = new RichPerson(1234,"firstName", "secondName", 30000000);

        underTest.save(richPerson);
        Optional<RichPerson> optionalRichPerson =underTest.findByClientID((long)1234);

        boolean exists = optionalRichPerson.isPresent();
        assertThat(exists).isTrue();
        RichPerson rich = optionalRichPerson.get();
        assertThat(rich).isEqualTo(richPerson);

    }

    @Test
    void test2(){
        Optional<RichPerson> optionalRichPerson =underTest.findByClientID((long)1234);

        boolean exists = optionalRichPerson.isPresent();
        assertThat(exists).isFalse();

    }

}
