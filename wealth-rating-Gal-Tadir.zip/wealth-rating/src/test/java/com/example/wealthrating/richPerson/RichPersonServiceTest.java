package com.example.wealthrating.richPerson;

import com.example.wealthrating.Client;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;


import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class RichPersonServiceTest {

    @Mock
    private RichPersonRepository richPersonRepository;
    private RichPersonService underTest;

    @BeforeEach
    void setUp() {
        underTest = new RichPersonService(richPersonRepository);
    }


    @Test
    void getAllRichesTest1() {
        underTest.getAllRiches();
        verify(richPersonRepository).findAll();
    }


    @Test
    void checkIfReachTest1() {

        Map<String,String>personalInfo = new HashMap<>();
        personalInfo.put("firstName", "Bill");
        personalInfo.put("lastName", "Gates");
        personalInfo.put("city", "Washington");
        Map<String,Number>financialInfo = new HashMap<>();
        financialInfo.put("cash",16000000000L);
        financialInfo.put("numberOfAssets", 50);

        Client client = new Client( 123456789,personalInfo,financialInfo );

        underTest.checkIfReach(client);

        ArgumentCaptor<RichPerson> argumentCaptor = ArgumentCaptor.forClass(RichPerson.class);
        verify(richPersonRepository).save(argumentCaptor.capture());
        RichPerson rich = argumentCaptor.getValue();

        assertThat(rich.getClientID()).isEqualTo(123456789);
        assertThat(rich.getFirstName()).isEqualTo("Bill");
        assertThat(rich.getLastName()).isEqualTo("Gates");
        assertThat(rich.getFortune()).isEqualTo(16050000000L);

    }

    @Test
    void checkIfReachTest2() {

        Map<String,String>personalInfo = new HashMap<>();
        personalInfo.put("firstName", "Bill");
        personalInfo.put("lastName", "Gates");
        personalInfo.put("city", "Washington");
        Map<String,Number>financialInfo = new HashMap<>();
        financialInfo.put("cash",160);
        financialInfo.put("numberOfAssets", 0);

        Client client = new Client( 123456789,personalInfo,financialInfo );

        RichPerson richPerson = underTest.checkIfReach(client);

        assertThat(richPerson).isEqualTo(null);

    }

    @Test
    void getRichPersonByClientId() {

        underTest.getRichPersonByClientId(123456789L);
        verify(richPersonRepository).findByClientID(123456789L);

    }

    @Test
    void getRichPersonById() {

        underTest.getRichPersonById(123456789L);
        verify(richPersonRepository).findById(123456789L);

    }
}
