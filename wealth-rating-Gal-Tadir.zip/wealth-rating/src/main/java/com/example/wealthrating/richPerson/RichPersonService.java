package com.example.wealthrating.richPerson;


import com.example.wealthrating.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Service
public class RichPersonService {
    private final RichPersonRepository richPersonRepository;
    private RestTemplate restTemplate;

    private HashMap<String,Long> defaultCitiesValues;
    private long defaultThreshold;


    @Autowired
    public RichPersonService(RichPersonRepository richPersonRepository) {
        this.richPersonRepository = richPersonRepository;
        this.restTemplate = new RestTemplate();

        this.defaultCitiesValues = new HashMap<>();
        defaultCitiesValues.put("Washington",(long)1000000);
        defaultCitiesValues.put("Los Angeles",(long)1500000);
        defaultCitiesValues.put("New York",(long)2000000);
        defaultCitiesValues.put("Chicago",(long)800000);
        defaultCitiesValues.put("Houston",(long)700000);
        defaultCitiesValues.put("Phoenix",(long)700000);
        defaultCitiesValues.put("Philadelphia",(long)1000000);
        defaultCitiesValues.put("Jerusalem",(long)1000000);
        defaultCitiesValues.put("Tel Aviv",(long)3000000);

        this.defaultThreshold = 20000000;

    }

    public RichPerson getRichPersonById(long id){
        Optional<RichPerson> richPerson = richPersonRepository.findById(id);
        return richPerson.orElse(null);
    }

    public List<RichPerson> getAllRiches(){
        return richPersonRepository.findAll();
    }

    @Transactional
    public RichPerson checkIfReach(Client client){
        long clientId = client.getId();
        String firstName = (String) client.getPersonalInfo().get("firstName");
        String lastName = (String) client.getPersonalInfo().get("lastName");
        String city = (String) client.getPersonalInfo().get("city");
        long cash;
        try{
            cash = (long) client.getFinancialInfo().get("cash");
        }catch (Exception e){
            cash = ((Integer) client.getFinancialInfo().get("cash")).longValue();
        }
        int numberOfAssets = (int)client.getFinancialInfo().get("numberOfAssets");


        String cityUrl = "http://central-bank/regional-info/evaluate?city="+city;
        Long cityAssetsValue;
        try{
            cityAssetsValue = restTemplate.getForObject(cityUrl, Long.class);
        }
        catch (Exception e){
            if(defaultCitiesValues.containsKey(city)){
                cityAssetsValue = defaultCitiesValues.get(city);
            }
            else {
                cityAssetsValue = (long)0;
            }
        }

        Long threshold;
        try{
            threshold = restTemplate.getForObject("http://central-bank/wealth-threshold", Long.class);
        }catch (Exception e){
            threshold = defaultThreshold;
        }

        long fortune = cash + numberOfAssets*cityAssetsValue;

        if(fortune>threshold){
            Optional<RichPerson> richPerson = richPersonRepository.findByClientID(clientId);
            if(richPerson.isPresent()){
                RichPerson richToUpdate = richPerson.get();
                richToUpdate.setFirstName(firstName);
                richToUpdate.setLastName(lastName);
                richToUpdate.setFortune(fortune);
                return richToUpdate;
            }
            return richPersonRepository.save(new RichPerson(clientId,firstName,lastName,fortune));
        }
        else {
            Optional<RichPerson> richPerson = richPersonRepository.findByClientID(clientId);
            if(richPerson.isPresent()){
                richPersonRepository.deleteById(richPerson.get().getID());
            }
            return null;
        }

    }

    public RichPerson getRichPersonByClientId(Long id) {
        Optional<RichPerson> richPerson = richPersonRepository.findByClientID(id);
        return richPerson.orElse(null);
    }
}
