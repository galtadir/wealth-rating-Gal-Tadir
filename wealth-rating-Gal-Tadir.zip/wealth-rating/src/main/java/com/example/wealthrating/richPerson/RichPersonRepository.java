package com.example.wealthrating.richPerson;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RichPersonRepository extends JpaRepository<RichPerson, Long> {


    @Query(value = "SELECT r FROM RichPerson r WHERE r.clientID=?1")
    Optional<RichPerson> findByClientID(Long aLong);

}
