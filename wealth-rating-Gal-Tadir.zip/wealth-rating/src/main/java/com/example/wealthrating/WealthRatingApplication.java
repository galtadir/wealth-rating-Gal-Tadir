package com.example.wealthrating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WealthRatingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WealthRatingApplication.class, args);
	}

}
