package com.example.wealthrating.richPerson;

import javax.persistence.*;

@Entity
@Table
public class RichPerson {

    @Id
    @SequenceGenerator(
            name = "rich_sequence",
            sequenceName = "rich_sequence",
            allocationSize = 1
    )
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rich_sequence")
    private long ID;
    private long clientID;
    private String firstName;
    private String lastName;
    private long fortune;

    public RichPerson(long clientID,String firstName, String lastName, long fortune) {
        this.clientID = clientID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.fortune = fortune;
    }

    public RichPerson() {
    }

    public long getClientID() {
        return clientID;
    }

    public void setClientID(long clientID) {
        this.clientID = clientID;
    }

    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getFortune() {
        return fortune;
    }

    public void setFortune(long fortune) {
        this.fortune = fortune;
    }
}
