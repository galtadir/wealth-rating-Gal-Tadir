package com.example.wealthrating.richPerson;

import com.example.wealthrating.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping(path="wealth-rating")
public class RichPersonController {

    private final RichPersonService richPersonService;

    @Autowired
    public RichPersonController(RichPersonService richPersonService) {
        this.richPersonService = richPersonService;
    }

    @GetMapping("/{id}")
    public RichPerson getByRichPersonId(@PathVariable Long id){
        RichPerson richPerson = richPersonService.getRichPersonById(id);
        if(richPerson==null){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "person not found");
        }
        return richPerson;
    }

    @GetMapping("/clientId:{id}")
    public RichPerson getByRichPersonClientId(@PathVariable Long id){
        RichPerson richPerson =  richPersonService.getRichPersonByClientId(id);
        if(richPerson==null){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "person not found");
        }
        return richPerson;
    }

    @GetMapping("/all")
    public List<RichPerson> getAll(){
        return richPersonService.getAllRiches();
    }

    @PostMapping("/client")
    public RichPerson clientRequest(@RequestBody Client client, HttpServletResponse response){
        RichPerson richPerson = richPersonService.checkIfReach(client);
        if(richPerson!=null){
            return richPerson;
        }
        throw new ResponseStatusException(HttpStatus.NO_CONTENT, "person isn't Rich");

    }

}

