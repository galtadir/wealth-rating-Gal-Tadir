package com.example.wealthrating;

import java.util.Map;

public class Client {
    private long id;
    private Map personalInfo;
    private Map financialInfo;

    public Client(long id, Map personalInfo, Map financialInfo) {
        this.id = id;
        this.personalInfo = personalInfo;
        this.financialInfo = financialInfo;
    }

    public long getId() {
        return id;
    }



    public Map getPersonalInfo() {
        return personalInfo;
    }



    public Map getFinancialInfo() {
        return financialInfo;
    }


}
